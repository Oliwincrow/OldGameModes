﻿using System;
using BepInEx;
using GorillaGameModes;
using UnityEngine;
using Utilla;
using Utilla.Attributes;
using Utilla.Models;

namespace OldGamemodes
{
    [ModdedGamemode("MODDED_Hunt", "MODDED HUNT", GameModeType.HuntDown)]
    [ModdedGamemode("MODDED_Ambush", "MODDED AMBUSH", GameModeType.Ambush)]
    [ModdedGamemode("MODDED_Ghost", "MODDED GHOST", GameModeType.Ghost)]
    [BepInPlugin(PluginInfo.GUID, PluginInfo.Name, PluginInfo.Version)]
    public class Plugin : BaseUnityPlugin { }
}

